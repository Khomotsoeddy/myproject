package application;

public abstract class Total {

	protected abstract double getTotal() ;

	
	protected abstract int serviceFee();

	protected abstract int subTotal();

	protected abstract int getnumber();
}
